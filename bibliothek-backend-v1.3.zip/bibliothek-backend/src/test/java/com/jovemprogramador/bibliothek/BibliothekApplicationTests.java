package com.jovemprogramador.bibliothek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliothekApplicationTests {

	@Test
	void contextLoads() {
	}

}
