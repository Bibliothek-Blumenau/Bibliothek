package com.jovemprogramador.bibliothek.security;

public record RegisterForm(String matricula, String nomeCompleto, String password, String roles) {
}
