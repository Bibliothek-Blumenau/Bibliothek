package com.jovemprogramador.bibliothek.security;

public record LoginResponse(String token) {
}
