package com.jovemprogramador.bibliothek.security;

public record LoginForm(String matricula, String password) {
}

